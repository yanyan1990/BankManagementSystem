package Connbean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionOracle {
	public static Connection connectOracle() throws ClassNotFoundException, SQLException{
		String url="jdbc:oracle:thin:@ANY:1521:Bank";
		String username="system";
		String password="123456";
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection=DriverManager.getConnection(url, username, password);
		return connection;
	}
	public static void closeOracle(Connection connection) throws SQLException{
		connection.close();
	}
}
